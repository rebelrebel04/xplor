library(testthat)
library(formattable)

test_check("formattable")
